/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alg;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

/**
 *
 * @author fuji
 */
public class Main {
    static int[] array;
    static HashSet<Integer> roots;
    static HashSet<Store> paths;
    static int[] inorder;
    static int[] finInorder;
    static int sumBig = Integer.MIN_VALUE;
    static int index = 0;

    static class Reader 
    { 
        final private int BUFFER_SIZE = 1 << 16; 
        private DataInputStream din; 
        private byte[] buffer; 
        private int bufferPointer, bytesRead; 
  
        public Reader() 
        { 
            din = new DataInputStream(System.in); 
            buffer = new byte[BUFFER_SIZE]; 
            bufferPointer = bytesRead = 0; 
        } 
  
        public Reader(String file_name) throws IOException 
        { 
            din = new DataInputStream(new FileInputStream(file_name)); 
            buffer = new byte[BUFFER_SIZE]; 
            bufferPointer = bytesRead = 0; 
        } 
  
        public String readLine() throws IOException 
        { 
            byte[] buf = new byte[64]; // line length 
            int cnt = 0, c; 
            while ((c = read()) != -1) 
            { 
                if (c == '\n') 
                    break; 
                buf[cnt++] = (byte) c; 
            } 
            return new String(buf, 0, cnt); 
        } 
  
        public int nextInt() throws IOException 
        { 
            int ret = 0; 
            byte c = read(); 
            while (c <= ' ') 
                c = read(); 
            boolean neg = (c == '-'); 
            if (neg) 
                c = read(); 
            do
            { 
                ret = ret * 10 + c - '0'; 
            }  while ((c = read()) >= '0' && c <= '9'); 
  
            if (neg) 
                return -ret; 
            return ret; 
        } 
  
        public long nextLong() throws IOException 
        { 
            long ret = 0; 
            byte c = read(); 
            while (c <= ' ') 
                c = read(); 
            boolean neg = (c == '-'); 
            if (neg) 
                c = read(); 
            do { 
                ret = ret * 10 + c - '0'; 
            } 
            while ((c = read()) >= '0' && c <= '9'); 
            if (neg) 
                return -ret; 
            return ret; 
        } 
  
        public double nextDouble() throws IOException 
        { 
            double ret = 0, div = 1; 
            byte c = read(); 
            while (c <= ' ') 
                c = read(); 
            boolean neg = (c == '-'); 
            if (neg) 
                c = read(); 
  
            do { 
                ret = ret * 10 + c - '0'; 
            } 
            while ((c = read()) >= '0' && c <= '9'); 
  
            if (c == '.') 
            { 
                while ((c = read()) >= '0' && c <= '9') 
                { 
                    ret += (c - '0') / (div *= 10); 
                } 
            } 
  
            if (neg) 
                return -ret; 
            return ret; 
        } 
  
        private void fillBuffer() throws IOException 
        { 
            bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE); 
            if (bytesRead == -1) 
                buffer[0] = -1; 
        } 
  
        private byte read() throws IOException 
        { 
            if (bufferPointer == bytesRead) 
                fillBuffer(); 
            return buffer[bufferPointer++]; 
        } 
  
        public void close() throws IOException 
        { 
            if (din == null) 
                return; 
            din.close(); 
        } 
    } 
 
    //vic cest vyplivnout arraylist objektu
    
        public static HashSet<Store> maxPathPart(int node, HashSet<Store> sums){
        if (node > array.length-1){
            return sums;
        }
        HashSet<Store> right = null;
        HashSet<Store> left = null;
       if (2*node+1 <= array.length-1 && array[2*node+1]!= 0){
          // System.out.println("leftak" + (2*node+1));
            left = maxPathPart(2*node+1, sums);
       } 
        if (2*node+2 <= array.length-1 && array[2*node+2]!= 0){
           // System.out.println("pravak" + (2*node+2));
            right = maxPathPart(2*node+2, sums);
        } 
        sums = new HashSet<>();
        counting++;
        System.err.println("counting" + counting);
       // System.out.println("Zde");
       if (left == null && right == null){
           sums = new HashSet<>();
            Store e = new Store();
            e.unused = new HashSet<>();
            e.sumBig = array[node];
            e.index = node;
            e.endl = node;
            e.endr = node;
            
            boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
            add = true;
            for (Store it : paths){     
                if(paths.isEmpty()){
                    paths.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        paths = new HashSet<>();;
                        paths.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                paths.add(e);
            }
            return sums;
       } if (left != null && right == null && left.isEmpty()){
            Store e = new Store();
            
            e.unused = new HashSet<>();
            e.sumBig = array[node];
            e.index = node;
            e.endl = node;
            e.endr = node;
                        boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
            add = true;
            for (Store it : paths){     
                if(paths.isEmpty()){
                    paths.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        paths = new HashSet<>();;
                        paths.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                paths.add(e);
            }
        }
              if (left == null && right != null && right.isEmpty()){
            Store e = new Store();
            
            e.unused = new HashSet<>();
            e.sumBig = array[node];
            e.index = node;
            e.endl = node;
            e.endr = node;
                        boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
            add = true;
            for (Store it : paths){     
                if(paths.isEmpty()){
                    paths.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        paths = new HashSet<>();;
                        paths.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                paths.add(e);
            }
        }

            if (left != null && right == null && !left.isEmpty()){
                int iter = 0;
                for (Store i : left){
                    int max_single = Math.max(Math.max(i.sumBig, 0) + array[node], array[node]);
                    int max_top = Math.max(max_single, i.sumBig+0+array[node]);
                    sumBig = Math.max(sumBig, max_top);
                    Store e = new Store();
                    
                    e.unused = new HashSet<>();
                    e.unused = (i.unused);
                    if (e.unused == null){
                        e.unused = new HashSet<>();
                    }
                    e.sumBig = max_single;
                    e.index = node;
                    e.endl = i.endl;
                    e.endr = node;
                    if (i.endl == i.index){
                        e.endl = i.endr;
                    }else{
                        e.endl = i.endl;
                    }
                    
                                boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
                     add = true;
                    for (Store it : paths){     
                        if(paths.isEmpty()){
                            paths.add(e);
                            add = false;
                            break;
                        } else{
                            if (e.sumBig > it.sumBig){
                                paths = new HashSet<>();;
                                paths.add(e);
                                add = false;
                            } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                                add = false;
                            }
                        }
                    }
                    if (add){
                        paths.add(e);
                    }
                    iter++;
            }
            return sums;
        }
        if (left == null && right != null && !right.isEmpty()){
            int iter = 0;
            for (Store j : right){
                int max_single = Math.max(Math.max(0, j.sumBig) + array[node], array[node]);
                int max_top = Math.max(max_single, 0+j.sumBig+array[node]);
                sumBig = Math.max(sumBig, max_top);
                Store e = new Store();
                
                e.unused = new HashSet<>();
                e.unused = (j.unused);
                if (e.unused == null){
                    e.unused = new HashSet<>();
                }
                e.sumBig = max_single;
                e.index = node;
                e.endl = node;
                if (j.endr == j.index){
                    e.endr = j.endl;
                }else{
                    e.endr = j.endr;
                }
                            boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
                add = true;
                for (Store it : paths){     
                    if(paths.isEmpty()){
                        paths.add(e);
                        add = false;
                        break;
                    } else{
                        if (e.sumBig > it.sumBig){
                            paths = new HashSet<>();;
                            paths.add(e);
                            add = false;
                        } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                            add = false;
                        }
                    }
                }
                if (add){
                    paths.add(e);
                }
 
            }
            iter++;
        }
        //System.out.println("Sel " + right.get(0).sumBig +" left " +left.get(0).sumBig);
        if (left != null && right != null){
        int iter = 0;
        int maxim = 0;
        System.err.println("left " + left.size() + " right "+right.size());
        sums = new HashSet<>();
        for (Store i : left){
            for (Store j : right){
                if (i.sumBig == j.sumBig){
                    int max_single = Math.max(Math.max(i.sumBig, j.sumBig) + array[node], array[node]);
                    int max_top = Math.max(max_single, i.sumBig+j.sumBig+array[node]);
                    sumBig = Math.max(sumBig, max_top);
                    Store e = new Store();
                    
                    e.unused = new HashSet<>();
                    e.unused = (j.unused);
                    e.unused.add(2*node+1);
                    e.sumBig = max_single;
                    e.index = node;
                    e.endl = node;
                    if (j.endr == j.index){
                        e.endr = j.endl;
                    }else{
                        e.endr = j.endr;
                    }
                    
                                boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
                    
                    
                    Store d = new Store();
                   
                    d.unused = new HashSet<>();
                    d.unused = (i.unused);
                    d.unused.add(2*node+2);
                    d.sumBig = max_single;
                    d.index = node;
                    
                    if (i.endl == i.index){
                        d.endl = i.endr;
                    }else{
                        d.endl = i.endl;
                    }
                    d.endr = node;
                                  add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(d);
                    add = false;
                    break;
                } else{
                    if (d.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(d);
                        add = false;
                    } else if (d.sumBig == it.sumBig && d.endl == it.endl && d.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(d);
            }
                    Store merged = new Store();
                    merged.unused = new HashSet<>();
                    merged.unused.addAll(e.unused);
                    //System.out.println("merged unused " + merged.unused);
                    merged.unused.remove(new Integer(2*node+1));
                    merged.unused.addAll(d.unused);
                    merged.unused.remove(new Integer(2*node+2));
                 //   System.out.println("merged unused " + merged.unused);
                    merged.sumBig = sumBig;
                    merged.index = node;
                    merged.endl = d.endl;
                    merged.endr = e.endr;
                  //  System.out.println("Sumbig " + sumBig);
                  //  System.out.println("Unused SIZ " + merged.unused.size() + " ITER " + iter);
                  
                    add = true;
                    for (Store it : paths){     
                        if(paths.isEmpty()){
                            paths.add(merged);
                            add = false;
                            break;
                        } else{
                            if (merged.sumBig > it.sumBig){
                                paths = new HashSet<>();;
                                paths.add(merged);
                                add = false;
                            } else if (merged.sumBig == it.sumBig && merged.endl == it.endl && merged.endr == it.endr){
                                add = false;
                            }
                        }
                    }
                    if (add){
                        paths.add(merged);
                    }
                    

                } else if (i.sumBig  < j.sumBig){
                    int max_single = Math.max(Math.max(i.sumBig, j.sumBig) + array[node], array[node]);
                    int max_top = Math.max(max_single, i.sumBig+j.sumBig+array[node]);
                    sumBig = Math.max(sumBig, max_top);
                 //   System.out.println("sumbbbbig " + max_top);
                    Store e = new Store();
                    
                    e.unused = new HashSet<>();
                    e.unused = (j.unused);
                    if (e.unused == null){
                        e.unused = new HashSet<>();
                    }
                    e.unused.add(2*node+1);
                    e.sumBig = max_single;
                    e.index = node;
                    e.endl = node;
                    if (j.endr == j.index){
                        e.endr = j.endl;
                    }else{
                        e.endr = j.endr;
                    }
                                boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }

                    add = true;
                    for (Store it : paths){     
                        if(paths.isEmpty()){
                            paths.add(e);
                            add = false;
                        } else{
                            if (e.sumBig > it.sumBig){
                                paths = new HashSet<>();;
                                paths.add(e);
                                add = false;
                            } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                                add = false;
                            }
                        }
                    }
                    if (add){
                        paths.add(e);
                    }
                    Store merged = new Store();
                    merged.unused = new HashSet<>();
                    merged.unused.addAll(e.unused);
                    merged.unused.remove(new Integer(2*node+1));
                    if (i.unused != null){
                        merged.unused.addAll(i.unused);
                    }
                    merged.sumBig = max_top;
                    merged.index = node;
                    merged.endl = e.endl;
                    if (i.endl == i.index){
                        merged.endl = i.endr;
                    }else{
                        merged.endl = i.endl;
                    }
                    merged.endr = e.endr;
                    add = true;
                    for (Store it : paths){     
                        if(paths.isEmpty()){
                            paths.add(merged);
                            add = false;
                            break;
                        } else{
                            if (merged.sumBig > it.sumBig){
                                paths = new HashSet<>();;
                                paths.add(merged);
                                add = false;
                            } else if (merged.sumBig == it.sumBig && merged.endl == it.endl && merged.endr == it.endr){
                                add = false;
                            }
                        }
                    }
                    if (add){
                        paths.add(merged);
                    }
                } else if (i.sumBig  > j.sumBig){
                    int max_single = Math.max(Math.max(i.sumBig, j.sumBig) + array[node], array[node]);
                    int max_top = Math.max(max_single, i.sumBig+j.sumBig+array[node]);
                    sumBig = Math.max(sumBig, max_top);
                    Store e = new Store();
                    
                    e.unused = new HashSet<>();
                    e.unused = (i.unused);
                    if (e.unused == null){
                        e.unused = new HashSet<>();
                    }
                    e.unused.add(2*node+2);
                    e.sumBig = max_single;
                    e.index = node;
                    e.endl = i.endl;
                    e.endr = node;
                    if (i.endl == i.index){
                        e.endl = i.endr;
                    }else{
                        e.endl = i.endl;
                    }
                                boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
                  //  System.out.println("endl " + sums.get(iter).endl + " sumBig " + max_single);
                     add = true;
                    for (Store it : paths){     
                        if(paths.isEmpty()){
                            paths.add(e);
                            add = false;
                        } else{
                            if (e.sumBig > it.sumBig){
                                paths = new HashSet<>();;
                                paths.add(e);
                                add = false;
                            } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                                add = false;
                            }
                        }
                    }
                    if (add){
                        paths.add(e);
                    }
                    Store merged = new Store();
                    merged.unused = new HashSet<>();
                    merged.unused.addAll(e.unused);
                    merged.unused.remove(new Integer(2*node+2));
                    if (j.unused != null){
                        merged.unused.addAll(j.unused);
                    }
                    merged.sumBig = max_top;
                    merged.index = node;
                    
                    merged.endl = e.endl;
                    merged.endr = e.endr;
                    if (j.endr == j.index){
                        merged.endr = j.endl;
                    }else{
                        merged.endr = j.endr;
                    }
                    add = true;
                    for (Store it : paths){     
                        if(paths.isEmpty()){
                            paths.add(merged);
                            add = false;
                            break;
                        } else{
                            if (merged.sumBig > it.sumBig){
                                paths = new HashSet<>();;
                                paths.add(merged);
                                add = false;
                            } else if (merged.sumBig == it.sumBig && merged.endl == it.endl && merged.endr == it.endr){
                                add = false;
                            }
                        }
                    }
                    if (add){
                        paths.add(merged);
                    }
                }
                iter++;
            }
        }
        }
        if (sums.isEmpty()){
            Store e = new Store();
            
            e.unused = new HashSet<>();
            e.sumBig = array[node];
            e.index = node;
            e.endl = node;
            e.endr = node;
                        boolean add = true;
            for (Store it : sums){     
                if(paths.isEmpty()){
                    sums.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        sums = new HashSet<>();;
                        sums.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                sums.add(e);
            }
            add = true;
            for (Store it : paths){     
                if(paths.isEmpty()){
                    paths.add(e);
                    add = false;
                    break;
                } else{
                    if (e.sumBig > it.sumBig){
                        paths = new HashSet<>();;
                        paths.add(e);
                        add = false;
                    } else if (e.sumBig == it.sumBig && e.endl == it.endl && e.endr == it.endr){
                        add = false;
                    }
                }
            }
            if (add){
                paths.add(e);
            }
        }



        return sums;
        
        
    }
    static int counting = 0;
    public static HashSet<Store> maxPathFinder(int node){
        HashSet<Store> sums = new HashSet<>();
        sumBig = Integer.MIN_VALUE;
        counting = 0;
        sums = maxPathPart(node, sums);;
        return sums;
    }
    
    public static void inOrder(int node){
        if (node > array.length-1){
            return;
        }
        inOrder(2*node+1);
        index++;
        inorder[node] = index;
        inOrder(2*node+2);
    }
    

    /**
     * @param args the command line arguments
     */
    //Inorder seznam done
    public static void main(String[] args) throws IOException {
        //QuickRead read = new QuickRead();
        Reader read=new Reader();   
       int nodes = read.nextInt();
        roots = new HashSet<>();
        array = new int[nodes];
        inorder = new int[nodes];
        finInorder = new int[nodes];
        paths = new HashSet<>();
        for (int i = 0; i < nodes; i++){
            array[i] = read.nextInt();
        }
        inOrder(0);
        roots.add(0);
        int finalInc = 0;

        while (!roots.isEmpty()){
            finalInc++;
            ///System.out.println("novy");
          //  System.out.println("rootsize "+roots.size());
           // for (int i : roots){
           //     System.out.println("Root " + roots.get(i));
                //maxPathFinder(i);
                maxPathFinder(roots.iterator().next());
           // }
           // System.out.println("Size of " + paths.size());
            
            // TODO  vyfiltrovat to a pak oznacit jako 0 a upravit ten cyklus nahore a melo by to byti
            // a jak najit to zkurvene minimum?
            System.err.println("paths siz " + paths.size());
            if (paths.size() > 1){
                int min = inorder[paths.iterator().next().index];
                for (Store i : paths){
                    if (inorder[i.index] < min){
                        min = inorder[i.index];
                    }
                   // System.out.println("sumB " + i.sumBig + " endl " + i.endl + " endr " + i.endr);
                }
                
                int siz = paths.size();
                for (Iterator<Store>  iterator = paths.iterator(); iterator.hasNext();){
                    Store value = iterator.next();
                    if (inorder[value.index] > min){
                        iterator.remove();
                    }
                }
                if (paths.size() > 1){
                    int abs = Math.abs(inorder[paths.iterator().next().endl] - inorder[paths.iterator().next().endr]);
                    siz = paths.size();
                    for (Store i : paths){
                        if (Math.abs(inorder[i.endl] - inorder[i.endr]) > abs){
                            abs = Math.abs(inorder[i.endl] - inorder[i.endr]);
                        }
                    }
                    siz = paths.size();
                    for (Iterator<Store>  iterator = paths.iterator(); iterator.hasNext();){
                        Store value = iterator.next();
                        if (Math.abs(inorder[value.endl] - inorder[value.endr]) < abs){
                            iterator.remove();
                        }
                    }
                    
                }
                //System.out.println("MAXpath is " +paths.get(0).sumBig+ " size " + paths.size() + " endl " + paths.get(0).endl+" endr "+paths.get(0).endr);
                array[paths.iterator().next().index]=0;
                for (int j: roots){
                    if (paths.iterator().next().index == j){
                        roots.remove(j);
                        for (int i : paths.iterator().next().unused){
                            if (i < nodes-1 &&array[i] != 0){
                                roots.add(i);
                //                System.out.println("Root are " + i);
                            }
                        }
                        break;
                    }
                }
                paths = new HashSet<>();
                
                sumBig = Integer.MIN_VALUE;
            } else if (paths.size() == 1){
                //this should be done
                //System.out.println("MAXpath is " +paths.get(0).sumBig+ " size " + paths.size() + " endl " + paths.get(0).endl+" endr "+paths.get(0).endr);
                array[paths.iterator().next().index] = 0; //null that shit
                for (int j: roots){
                    if (paths.iterator().next().index == j){
                        roots.remove(j);
                        for (int i : paths.iterator().next().unused){
                            if (i < nodes-1 &&array[i] != 0){
                                roots.add(i);
              //                  System.out.println("Root are " + i);
                            }
                        }
                        break;
                    }
                }
                sumBig = Integer.MIN_VALUE;
                paths = new HashSet<>();
            }
        }
        System.out.println(finalInc);
    }
    

    
}
