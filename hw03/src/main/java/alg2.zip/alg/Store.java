/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alg;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author fuji
 */
public class Store {
    int root;
    int endl;
    int endr;
    int index;
    int sumBig;
    HashSet<Integer> unused;

    public Store(int root, int endl, int endr) {
        this.root = root;
        this.endl = endl;
        this.endr = endr;
    }

    public Store() {
    }
    
}
