/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alg;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;

/**
 *
 * @author fuji
 */
public class Main {
    static int length;
    static int width;
    static int counter = 0;
    static ArrayList<Integer> globCounter;
    

        static class Reader 
    { 
        final private int BUFFER_SIZE = 1 << 16; 
        private DataInputStream din; 
        private byte[] buffer; 
        private int bufferPointer, bytesRead; 
  
        public Reader() 
        { 
            din = new DataInputStream(System.in); 
            buffer = new byte[BUFFER_SIZE]; 
            bufferPointer = bytesRead = 0; 
        } 
  
        public Reader(String file_name) throws IOException 
        { 
            din = new DataInputStream(new FileInputStream(file_name)); 
            buffer = new byte[BUFFER_SIZE]; 
            bufferPointer = bytesRead = 0; 
        } 
  
        public String readLine() throws IOException 
        { 
            byte[] buf = new byte[64]; // line length 
            int cnt = 0, c; 
            while ((c = read()) != -1) 
            { 
                if (c == '\n') 
                    break; 
                buf[cnt++] = (byte) c; 
            } 
            return new String(buf, 0, cnt); 
        } 
  
        public int nextInt() throws IOException 
        { 
            int ret = 0; 
            byte c = read(); 
            while (c <= ' ') 
                c = read(); 
            boolean neg = (c == '-'); 
            if (neg) 
                c = read(); 
            do
            { 
                ret = ret * 10 + c - '0'; 
            }  while ((c = read()) >= '0' && c <= '9'); 
  
            if (neg) 
                return -ret; 
            return ret; 
        } 
  

  
        private void fillBuffer() throws IOException 
        { 
            bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE); 
            if (bytesRead == -1) 
                buffer[0] = -1; 
        } 
  
        private byte read() throws IOException 
        { 
            if (bufferPointer == bytesRead) 
                fillBuffer(); 
            return buffer[bufferPointer++]; 
        } 
  
        public void close() throws IOException 
        { 
            if (din == null) 
                return; 
            din.close(); 
        } 
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Reader read=new Reader(); 
        
        //loading size
        length = read.nextInt();
        width = read.nextInt();
        
        //global counter
        globCounter = new ArrayList<>();
        //loading matrix
        int matrix[][] = new int[length][width];
        //creating graph of sectors
        int sectors[][] = new int[length][width];
        //helping graph
        boolean helper[][] = new boolean[length][width];
        //array of prices
        ArrayList<Integer> prices = new ArrayList<>();
        
        //loading start;
        int start[] = new int[2];
        start[0] = read.nextInt();
        start[1] = read.nextInt();
        start[0]+=-1;
        start[1]+=-1;
        
        //loading end
        int end[] = new int[2];
        end[0] = read.nextInt();
        end[1] = read.nextInt();
        end[0]+=-1;
        end[1]+=-1;
        //intialize matrix
        for (int i = 0; i < length; i++){
           for (int j = 0; j < width; j++){
               matrix[i][j] = read.nextInt();
           }    
        }
        //intializes sectors matrix
        for (int i = 0; i < length; i++){
               sectors[i] = matrix[i].clone();   
        }
      /*  System.out.println("---------");
        for (int i = 0; i < length; i++){
           for (int j = 0; j < width; j++){
              System.out.print(sectors[i][j] + " ");
           } 
           System.out.println();
        }*/
        
      //  System.out.println(start[0] + " " + start[1]);
    //    System.out.println(end[0] + " " + end[1]);
        
        //fill the sectors by bfs
        for (int i = 0; i < length; i++){
           for (int j = 0; j < width; j++){
               if (helper[i][j] !=  true){
                   //Udelam bfs pro ten uzel
                   counter = 0;
                   BFS(i, j, helper, matrix, sectors);                   
                   prices.add(counter);
               }
           }
        }
        //fill the sectors matrix
        int ind = 0;
        helper = new boolean[length][width];
        for (int i = 0; i < length; i++){
           for (int j = 0; j < width; j++){
               if (helper[i][j] !=  true){
                   int temp = prices.get(ind);
                   BFS2(i, j, helper, matrix, sectors, temp);                   
                   ind++;
               }
           }
        }
      /*  System.out.println("------------------------");
        for (int i = 0; i < length; i++){
           for (int j = 0; j < width; j++){
                System.out.print(sectors[i][j] +" ");               
           }
           System.out.println();
        }*/
        
        //lets do finding best path
        helper = new boolean[length][width];
        ArrayList<Store> bestPath = upgradedBFS(sectors, start, end, helper);
        //co nejmensi pocet rekonfiguraci a kdyz se rovnaji tak vzit kratsi
        int recog;
        int dist;
        //System.out.println("Size " + bestPath.size());
        int minReconfig = Integer.MAX_VALUE;
        for (int i = 0; i < bestPath.size(); i++){
            if (bestPath.get(i).reconfig < minReconfig){
                minReconfig = bestPath.get(i).reconfig;
            }
        }
        for (int i = bestPath.size()-1; i >= 0; i--){
            if (bestPath.get(i).reconfig > minReconfig){
                bestPath.remove(i);
            }
        }
        //ted pro cesty
        minReconfig = Integer.MAX_VALUE;
        for (int i = 0; i < bestPath.size(); i++){
            if (bestPath.get(i).distance < minReconfig){
                minReconfig = bestPath.get(i).distance;
            }
        }
        for (int i = bestPath.size()-1; i >= 0; i--){
            if (bestPath.get(i).distance > minReconfig){
                bestPath.remove(i);
            }
        }
        System.out.println(bestPath.get(0).reconfig + " " + bestPath.get(0).distance);
        
    }
    
    static void BFS(int i, int j ,  boolean [][]helper, int[][] matrix, int[][] sectors){
   
        //set the node as visited
        helper[i][j] = true;
        counter++;
        //todo left
        if (j-1 >= 0){
            if (matrix[i][j-1] != matrix[i][j] || helper[i][j-1] == true){
            }else{
                BFS(i, j-1, helper, matrix, sectors);
            }
            
        }
        //todo right
        if (j+1 < width){
            if (matrix[i][j+1] != matrix[i][j]|| helper[i][j+1] == true){
            }else{
                BFS(i, j+1, helper, matrix, sectors);
            }
        }
        //todo up
        if (i+1 < length){
            if (matrix[i+1][j] != matrix[i][j]|| helper[i+1][j] == true){
                return;
            }else{
                BFS(i+1, j, helper, matrix, sectors);
            }
        }
        //todo down
        if (i-1 >= 0){
            if (matrix[i-1][j] != matrix[i][j]|| helper[i-1][j] == true){
            } else{
                BFS(i-1, j, helper, matrix, sectors);
            }
        }
        
        
        
    }
    
        static void BFS2(int i, int j ,  boolean [][]helper, int[][] matrix, int[][] sectors, int temp){
   
        //set the node as visited
        helper[i][j] = true;
        sectors[i][j] = temp;
        //todo left
        if (j-1 >= 0){
            if (matrix[i][j-1] != matrix[i][j] || helper[i][j-1] == true){
            }else{
                sectors[i][j-1] = temp;
                BFS2(i, j-1, helper, matrix, sectors, temp);
            }
            
        }
        //todo right
        if (j+1 < width){
            if (matrix[i][j+1] != matrix[i][j]|| helper[i][j+1] == true){
            }else{
                sectors[i][j+1] = temp;
                BFS2(i, j+1, helper, matrix, sectors, temp);
            }
        }
        //todo up
        if (i+1 < length){
            if (matrix[i+1][j] != matrix[i][j]|| helper[i+1][j] == true){
            }else{
                sectors[i+1][j] = temp;
                BFS2(i+1, j, helper, matrix, sectors, temp);
            }
        }
        //todo down
        if (i-1 >= 0){
            if (matrix[i-1][j] != matrix[i][j]|| helper[i-1][j] == true){
            } else{
                sectors[i-1][j] = temp;
                BFS2(i-1, j, helper, matrix, sectors, temp);
            }
        }
    }
        
    static ArrayList<Store> upgradedBFS(int [][]sectors, int[]start, int end[], boolean[][] helper){        
        //set start as visited
        helper[start[0]][start[1]] = true;
        ArrayList<Store> bestPath = new ArrayList<>();
        //linkd list for bfs
        LinkedList<Store> que = new LinkedList<>();
        
        //distance is 0, reconfig is 0
        Store st = new Store(start[0], start[1], 0, 0);
        que.add(st); // push it
        
        
        //2d array of stores
        Store[][] nodes = new Store[length][width];
        nodes[start[0]][start[1]] = st;
        //do bfs from start
        while (!que.isEmpty()){
            //mozna getFirst
                Store temp = que.poll();
            
            if (temp.i == end[0] && temp.j == end[1]){
             //   System.out.println("Dosel do cile "+ temp.reconfig + " " + temp.distance);
                bestPath.add(temp);
            }
            
            int col[] = {0, -1, 1, 0};
            int row[] = {-1, 0, 0, 1};
            
            for (int i = 0; i < 4; i++){
                int rows = temp.i + row[i];
                int cols = temp.j + col[i];
                
                //if ok put it to queue
                if (rows >= 0 && cols >= 0 && rows < length && cols < width && helper[rows][cols] == false){
                    helper[rows][cols] = true;
                    int reconfig = temp.reconfig;
                    if (Math.abs(sectors[temp.i][temp.j] - sectors[rows][cols]) > Math.min(sectors[temp.i][temp.j], sectors[rows][cols])){
                   //     System.out.println("From1 " + temp.i + " " + temp.j);
                   //     System.out.println("To1 " + rows + " " + cols);                 
                        reconfig+=1;
                    }
                    Store fresh = new Store(rows, cols, temp.distance+1, reconfig);
                    nodes[rows][cols] = fresh;
                    que.add(fresh);
                }else if (rows >= 0 && cols >= 0 && rows < length && cols < width){
                    int reconfig = temp.reconfig;
                    if (Math.abs(sectors[temp.i][temp.j] - sectors[rows][cols]) > Math.min(sectors[temp.i][temp.j], sectors[rows][cols])){
                      //  System.out.println("From2 " + temp.i + " " + temp.j);
                       // System.out.println("To2 " + rows + " " + cols);                  
                        reconfig+=1;
                        
                    }
                    if (reconfig < nodes[rows][cols].reconfig){
                        Store fresh = new Store(rows, cols, temp.distance+1, reconfig);
                        nodes[rows][cols] = fresh;
                        que.add(fresh);
                    }
                }
            }
            
        }
        return bestPath;
    }
    
    
}
