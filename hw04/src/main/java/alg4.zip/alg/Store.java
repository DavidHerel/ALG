/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alg;

/**
 *
 * @author fuji
 */
public class Store{
    int i;
    int j;
    int distance;
    int reconfig;
    boolean popped;

    public Store(int i, int j, int distance, int reconfig) {
        this.i = i;
        this.j = j;
        this.distance = distance;
        this.reconfig = reconfig;
        this.popped = false;
    }
    
    public int Compare(Store s){
        if (this.reconfig < s.reconfig){
            return 0;
        }
        if (this.reconfig == s.reconfig){
            if (this.distance < s.distance){
                return 0;
            }
            if (this.distance > s.distance){
                return 1;
            }
        }
        if (this.reconfig > s.reconfig){
            return 1;
        }
        return 0;
    }



}
